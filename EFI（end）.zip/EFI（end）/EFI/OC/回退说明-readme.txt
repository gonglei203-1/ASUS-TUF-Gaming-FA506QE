NVIDIA（NullMoth 社区驱动）安装记录 / 回退说明
日期：2026-11-15  机器：ASUS 笔记本（Ryzen 7 5800H + Radeon RX Renoir 核显 + RTX 3050 Ti Laptop 10de:25a0）
系统：macOS 15.6 Sequoia（OpenCore 引导）  驱动版本：NullMoth NVIDIA 3.0

一、这次改了什么
1) /Library/Extensions 新增：NVRM.kext、NVAccel.kext、NVRMFB.kext、NVRMAGDC.kext
2) /Library/GPUBundles 新增：NVMTLDriver.bundle（Metal 插件）
3) /Library/NullMoth 新增：GSP 固件(nvfw)、安装备份、状态文件
4) AuxiliaryKernelExtensions.kc 已重建（四个 kext 已写入内核集合）
5) EFI/OC/config.plist 两处修改：
   - NVRAM boot-args 追加：nvfb=1 nvaccel=1 nvfbheads=4 -nvkmsnosmooth
   - Kernel -> Block 新增一条：com.apple.iokit.IONDRVSupport，Strategy=Exclude
   其余（csr-active-config=0x0A43、SecureBootModel=Disabled、Lilu/AMFIPass）本来就是合格状态，未改动。

二、回退方式
A. macOS 还能进，但显卡/桌面异常：
   1. 在 macOS 里执行卸载（会把驱动文件与内核集合还原）：
      sudo "/Users/gl/Doubao/chats/2026-11-15/new-chat/nvidia-driver/pkgroot/uninstall.sh" /Library/NullMoth/backup-20261115-110900.v8c2S7
   2. 把 config.plist 换回安装前的备份：
      cp "/Users/gl/Doubao/chats/2026-11-15/new-chat/nvidia-driver/config.plist.bak-20261115" "/Volumes/MAC/EFI/OC/config.plist"
   3. 重启。

B. macOS 完全起不来（黑屏 / 卡住 / 内核崩溃）：
   1. 重启，选 Windows 11 启动。
   2. 在 Windows 里打开卷标为 MAC 的 FAT 分区（就是 OpenCore 的 EFI 盘）。
   3. 进入 EFI\OC\ 目录，把 config.plist.bak-nullmoth-before 复制/改名为 config.plist 覆盖现有文件。
      （这就是安装前的原始配置，去掉 nvfb/nvaccel 参数后驱动不会启动）
   4. 重启回 macOS；进去之后再按上面 A 的第 1 步卸载驱动文件。

三、验证（重启两次后执行）
   kmutil showloaded --list-only | grep nullmoth
     期望 4 行：NVRM / NVAccel / NVRMFB / NVRMAGDC
   system_profiler SPDisplaysDataType | head -20
     期望看到 GeForce RTX 3050 Ti Laptop 且 Metal: supported

四、已知注意事项
- 首次带驱动启动可能在 "PCI configuration end" 停约 1 分钟，属正常，别断电。
- 如果 macOS 弹出"系统扩展被阻止"，去 系统设置 -> 隐私与安全性 点允许，然后再重启一次。
- 桌面闪烁/拖动鼠标撕裂：boot-args 加 -nvrmnoflip。
- 睡眠唤醒后显卡掉了：boot-args 加 -nvrmnopm（会关掉休眠）。
- 笔记本内屏是核显直连（无 MUX），驱动默认接管不了内屏；要让独显参与渲染需要实验项 nmhybrid（1401 Mac App 里开）。
- 本机原本就关闭了 Secure Boot、放宽了 SIP（csr-active-config=0x0A43），装这个驱动没有进一步削弱系统防护。
